To compile, run the script compile.sh:

		./compile.sh

In order to run the program do: 

		./calc_grammar < "inpuft file name here"

	- Example:

			./calc_grammar < input.c